import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';
import '../styles/responsive.css';
import data from '/src/DATA.json';

let html = "";
data.restaurants.forEach((resto) => {
html += `
    <article class="post-item">
        <p tabindex="0" class="post-item__city">
            <span class="post-item__city__author">${resto.city}</span>
        </p>
        <img tabindex="0" class="post-item__thumbnail"
        src="${resto.pictureId}"
        alt="Gambar suasana restoran yang berada di ${resto.city}" 
        />
        <div tabindex="0" class="post-item__rating">
            <h3>Rating : ${resto.rating}</h3>
        </div>
        <div class="post-item__content">
            <h1 class="post-item__title"><a href="#">${resto.name}</a></h1>
            <p tabindex="0" class="post-item__description">${resto.description}</p>
        </div>
    </article>
`;
document.getElementById("item").innerHTML = html;
});

const menu = document.querySelector('.menu-toggle');
const input = document.querySelector('.menu-toggle input');
const hero = document.querySelector('.hero');
const main = document.querySelector('main');
const drawer = document.querySelector('.nav__list');

menu.addEventListener('click', function (event) {
    drawer.classList.toggle('slide');
    event.stopPropagation();
});

hero.addEventListener('click', function () {
    drawer.classList.remove('slide');
});

main.addEventListener('click', function () {
    drawer.classList.remove('slide');
});

menu.addEventListener('keydown', () => {
    if (input.checked) {
        input.checked = false;
    } else {
        input.checked = true;
    }
    drawer.classList.toggle('slide');
});